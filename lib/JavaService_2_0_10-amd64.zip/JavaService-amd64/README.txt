This directory contains a slightly modified version of the JavaService
executable, version 2.0.10.0, distributed under LGPL by ObjectWeb 
(http://javaservice.objectweb.org)

The code was patched to fix a number of compilation warnings when building
for amd64 architecture.
